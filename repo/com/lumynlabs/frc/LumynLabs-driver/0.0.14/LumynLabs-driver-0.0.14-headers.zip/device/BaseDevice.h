#pragma once

#include "IDevice.h"
#include "networking/ILumynTransmissionHandler.h"
#include "networking/TransmissionPortListener.h"

namespace lumyn::internal
{
  typedef void (*EventCallback_t)(const Eventing::Event *);

  class BaseDevice : public ILumynTransmissionHandler
  {
  public:
    BaseDevice(std::function<void(const Transmission::Transmission &)> onTransmission,
               std::function<void(const Eventing::Event &)> onEvent);

    virtual ~BaseDevice();

    bool Connect(HAL_SerialPort);
    bool IsConnected(void);
    Eventing::Status GetCurrentStatus(void);
    std::optional<Eventing::Event> GetLatestEvent(void);
    void HandleEvent(const Eventing::Event &) override;
    void HandleTransmission(const Transmission::Transmission &) override;

  protected:
    bool Initialize(void);

    std::optional<Response::ResponseHandshakeInfo> GetLatestHandshake(void);
    std::unique_ptr<TransmissionPortListener> _portListener;

  private:
    bool Handshake(void);

    std::function<void(const Transmission::Transmission &)> _onTransmission;
    std::function<void(const Eventing::Event &)> _onEvent;
    std::optional<Response::ResponseHandshakeInfo> _latestHandshake;
    std::optional<Eventing::Event> _latestEvent;
    std::optional<std::pair<Eventing::HeartBeatInfo, int64_t>> _latestHeartbeat;
  };
}