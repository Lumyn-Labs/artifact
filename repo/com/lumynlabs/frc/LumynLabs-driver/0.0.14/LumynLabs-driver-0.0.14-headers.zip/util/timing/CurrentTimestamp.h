#pragma once

#include <hal/cpp/fpga_clock.h>

#include <cinttypes>

namespace lumyn::internal::util::timing
{
  class CurrentTimestamp
  {
  public:
    static int64_t GetCurrentTimestampMs()
    {
      auto now = hal::fpga_clock::now();
      auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch());

      return ms.count();
    }
  };
}