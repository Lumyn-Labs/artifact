#pragma once

#include <iostream>
#include "util/logging/ConsoleLogger.h"
#include "packed.h"

namespace lumyn::internal
{

  constexpr size_t MAX_PACKET_SIZE = 256;
  constexpr uint8_t PACKET_MARKER = 0x00;

  PACK(struct PacketHeader {
    uint16_t packetId;
    uint8_t length;
    uint8_t crc;

    static constexpr size_t baseSize()
    {
      return sizeof(packetId) + sizeof(length) + sizeof(crc);
    }
  });

  const size_t MAX_PACKET_BODY_SIZE = MAX_PACKET_SIZE - sizeof(PacketHeader);

  struct Packet
  {
    PacketHeader header;
    uint8_t buf[MAX_PACKET_BODY_SIZE];

    static Packet fromBuffer(const uint8_t buffer[], size_t bufferSize)
    {
      if (bufferSize < PacketHeader::baseSize())
      {
        lumyn::internal::consoleLogger.getInstance().logError("Packet", "Buffer is too small to contain packet header");
      }

      Packet packet;
      size_t offset = 0;

      packet.header.packetId = buffer[offset] | (buffer[offset + 1] << 8);
      offset += sizeof(packet.header.packetId);

      packet.header.length = buffer[offset];
      offset += sizeof(packet.header.length);

      packet.header.crc = buffer[offset];
      offset += sizeof(packet.header.crc);

      if (packet.header.length > MAX_PACKET_BODY_SIZE)
      {
        lumyn::internal::consoleLogger.getInstance().logError("Packet", "Packet body is too large");
      }

      if (bufferSize < offset + packet.header.length)
      {
        lumyn::internal::consoleLogger.getInstance().logError("Packet", "Buffer is too small to contain packet body");
      }

      std::memcpy(packet.buf, buffer + offset, packet.header.length);

      return packet;
    }

    static char *raw(const Packet &packet)
    {
      static char raw[MAX_PACKET_SIZE];
      size_t offset = 0;

      raw[offset] = packet.header.packetId & 0xFF;
      raw[offset + 1] = (packet.header.packetId >> 8) & 0xFF;
      offset += sizeof(packet.header.packetId);

      raw[offset] = packet.header.length;
      offset += sizeof(packet.header.length);

      raw[offset] = packet.header.crc;
      offset += sizeof(packet.header.crc);

      std::memcpy(raw + offset, packet.buf, packet.header.length);

      return raw;
    }
  };
} // namespace lumyn::internal