#pragma once

#include "domain/command/led/LEDCommand.h"
#include "./Animation.h"

#include <units/time.h>
#include <functional>

namespace lumyn::internal
{
  class LEDCommander
  {
  public:
    LEDCommander(std::function<void(Command::LED::LEDCommand &)> handler) : _cmdHandler{handler} {}

    Command::LED::LEDCommand SetColor(std::string_view, Command::LED::AnimationColor);
    Command::LED::LEDCommand SetGroupColor(std::string_view, Command::LED::AnimationColor);
    Command::LED::LEDCommand SetAnimation(std::string_view, led::Animation,
                                          Command::LED::AnimationColor, units::millisecond_t delay = 250_ms,
                                          bool reversed = false, bool oneShot = false);
    Command::LED::LEDCommand SetGroupAnimation(std::string_view, led::Animation,
                                               Command::LED::AnimationColor, units::millisecond_t delay = 250_ms,
                                               bool reversed = false, bool oneShot = false);
    Command::LED::LEDCommand SetAnimationSequence(std::string_view, std::string_view);
    Command::LED::LEDCommand SetGroupAnimationSequence(std::string_view, std::string_view);

  private:
    std::function<void(Command::LED::LEDCommand &)> _cmdHandler;
  };
}