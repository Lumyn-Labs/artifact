#pragma once

#include "domain/event/Event.h"

#include <functional>

class EventHandler
{
public:
  EventHandler(std::function<void(const lumyn::internal::Eventing::Event &evt)> handler) : _handler{handler} {}
  void Handle(const lumyn::internal::Eventing::Event &evt)
  {
    if (_handler) {
      _handler(evt);
    }
  }

private:
  std::function<void(const lumyn::internal::Eventing::Event &evt)> _handler;
};