#pragma once

#include "device/BaseDevice.h"
#include "connectorXVariant/IConnectorXVariant.h"

namespace lumyn::internal
{
  class BaseConnectorXVariant : public BaseDevice
  {
  public:
    BaseConnectorXVariant();

    virtual ~BaseConnectorXVariant();

  protected:
    virtual void HandleNewModuleData(const ModuleData::ModuleData &data) = 0;
    virtual void HandleEvent(const Eventing::Event &) = 0;

    std::optional<const Response::Response> SendRequest(Request::Request &request, int timeoutMs = 10000);
    void SendCommand(const Command::Command &command);

  private:
    void HandleTransmission(const Transmission::Transmission &);
  };
}