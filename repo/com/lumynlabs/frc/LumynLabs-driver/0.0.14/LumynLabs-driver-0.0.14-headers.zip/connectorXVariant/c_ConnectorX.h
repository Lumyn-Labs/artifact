#pragma once

#include "./ConnectorX.h"

namespace lumyn::internal::c_ConnectorX
{
  class ConnectorX_int
  {
  public:
    ConnectorX &GetInner()
    {
      if (!_inst)
      {
        _inst = new ConnectorX();
      }

      return *_inst;
    }

    ~ConnectorX_int()
    {
      if (_inst)
      {
        delete _inst;
      }
    }

  private:
    ConnectorX *_inst;
  };

#ifdef __cplusplus
  extern "C"
  {
#endif
    /**
     * MUST BE DELETED
     */
    ConnectorX_int *cx_CreateInstance(void);

    bool cx_Connect(ConnectorX_int *, HAL_SerialPort);
    bool cx_IsConnected(ConnectorX_int *);
    Eventing::Status cx_GetCurrentStatus(ConnectorX_int *);
    bool cx_GetLatestEvent(ConnectorX_int *, Eventing::Event *);

    void cx_SetEventCallback(ConnectorX_int *, std::function<void(const lumyn::internal::Eventing::Event&)>);

    // If modules are enabled for the variant...
    void cx_RegisterModule(ConnectorX_int *, const char *, std::function<void(const lumyn::internal::ModuleData::NewDataInfo&)>);
    void cx_ExtractData(ConnectorX_int *, ModuleData::NewDataInfo *, void *);
    bool cx_GetLatestData(ConnectorX_int *, const char *, void *);

    // If LEDs are enabled for the variant...
    void cx_SetColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetGroupColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                         units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetGroupAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                              units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetAnimationSequence(ConnectorX_int *, const char *, const char *);
    void cx_SetGroupAnimationSequence(ConnectorX_int *, const char *, const char *);

    void cx_SetBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                      bool setColor = false, bool oneShot = false);
    void cx_SetGroupBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                           bool setColor = false, bool oneShot = false);
    void cx_SetText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                    Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                    units::millisecond_t delayMs = 500_ms, bool oneShot = false);
    void cx_SetGroupText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                         Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                         units::millisecond_t delayMs = 500_ms, bool oneShot = false);

#ifdef __cplusplus
  }
#endif
}