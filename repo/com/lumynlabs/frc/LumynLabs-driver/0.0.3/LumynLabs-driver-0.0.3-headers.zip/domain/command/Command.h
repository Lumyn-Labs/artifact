#pragma once

#include "domain/command/CommandType.h"

namespace Command {
struct __attribute__((packed)) Command {
  APIGroupType type;
  union {
    LED::LEDCommand led;
    System::SystemCommand system;
  };
};
};  // namespace Command