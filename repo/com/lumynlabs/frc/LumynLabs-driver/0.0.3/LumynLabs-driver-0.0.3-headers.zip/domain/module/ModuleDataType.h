#pragma once

#include <cinttypes>

namespace ModuleData {
enum class ModuleDataType : uint8_t { NewData = 0 };
}  // namespace ModuleData