#pragma once

#include "domain/event/Event.h"
#include "domain/request/RequestType.h"

// needed because in firmware this is included from outside the domain
namespace SystemStatus {
  enum class Status : uint8_t { Booting = 0, Active, Error, Fatal };
}  // namespace SystemStatus

namespace Response {
struct __attribute__((packed)) ResponseStatusInfo {
  SystemStatus::Status status;
};
struct __attribute__((packed)) ResponseProductSKUInfo {
  uint16_t sku;
};
struct __attribute__((packed)) ResponseProductSerialNumberInfo {
  uint32_t serialNumber;
};
struct __attribute__((packed)) ResponseConfigHashInfo {
  uint8_t hash[16];
};
struct __attribute__((packed)) ResponseAssignedIdInfo {
  uint8_t valid;
  char id[24];
};
struct __attribute__((packed)) ResponseHandshakeInfo {
  ResponseStatusInfo status;
  ResponseProductSKUInfo sku;
  ResponseProductSerialNumberInfo serNumber;
  ResponseConfigHashInfo configHash;
  ResponseAssignedIdInfo assignedId;
};
struct __attribute__((packed)) ResponseFaultsInfo {
  uint32_t faultFlags;
};
struct __attribute__((packed)) ResponseDeviceStatusInfo {
  uint16_t deviceId;
  uint8_t status;
};
struct __attribute__((packed)) ResponseDeviceDataInfo {
  uint16_t deviceId;
  // TODO: constant for max data size
  uint8_t data[16];
  uint8_t length;
};
struct __attribute__((packed)) ResponseLEDChannelStatusInfo {
  uint16_t channelId;
};
struct __attribute__((packed)) ResponseLEDZoneStatusInfo {
  uint16_t zoneId;
};
struct __attribute__((packed)) ResponseLatestEventInfo {
  Eventing::EventType eventType;
};
struct __attribute__((packed)) ResponseEventFlagsInfo {
  uint32_t eventFlags;
};

struct __attribute__((packed)) Response {
  Request::RequestType type;
  // Should match the incoming Request's ID
  uint32_t id;
  union {
    ResponseHandshakeInfo handshake;
    ResponseStatusInfo status;
    ResponseProductSKUInfo productSku;
    ResponseProductSerialNumberInfo productSerialNumber;
    ResponseConfigHashInfo configHash;
    ResponseAssignedIdInfo assignedId;
    ResponseFaultsInfo faults;
    ResponseDeviceStatusInfo deviceStatus;
    ResponseDeviceDataInfo deviceData;
    ResponseLEDChannelStatusInfo ledChannelStatus;
    ResponseLEDZoneStatusInfo ledZoneStatus;
    ResponseLatestEventInfo latestEvent;
    ResponseEventFlagsInfo eventFlags;
  };
};

constexpr auto sz = sizeof(Response);
}  // namespace Response