#pragma once

#include <cinttypes>

#include "FileType.h"

namespace Files {
struct __attribute__((packed)) FileTransferInfoHeader {
  char path[32];
};

struct __attribute__((packed)) SendConfigInfoHeader {};

struct __attribute__((packed)) FilesHeader {
  FileType type;
  union {
    FileTransferInfoHeader fileTransfer;
    SendConfigInfoHeader sendConfig;
  };
  uint16_t md5;
  uint32_t fileSize;
};

struct __attribute__((packed)) Files {
  FilesHeader header;
  uint8_t* bytes;
};
}  // namespace Files