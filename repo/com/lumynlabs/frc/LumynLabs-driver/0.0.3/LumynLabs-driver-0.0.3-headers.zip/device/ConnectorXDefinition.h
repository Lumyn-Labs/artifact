#pragma once

#include "DeviceDefinition.h"

DeviceDefinition ConnectorXDefinition = {
    .info = {
        .id = "cx",
        .name = "ConnectorX",
        .version = "3.1.0a",
        .productUrl = "https://shop.lumynlabs.com/connectorx",
        .productImgUrl = "/product_imgs/connector-x.jpg",
        .usbVendorId = "",
        .usbProductId = "",
        .usbDebugProductId = "",
        .regulatorOutputMa = 4000,
        .supportedCommunication = {CommunicationType::USB, CommunicationType::I2C, CommunicationType::UART}
    },
    .features = {
        .enableLEDs = true,
        .enableDevices = true,
        .enableScreen = true,
        .enableMic = false,
        .enableDIO = true,
        .enableAIO = true
    },
    .led = LEDConfiguration{
        .ledPowerDrawMa = 60,
        .channelCount = 4
    },
    .devices = DeviceConfiguration{
        .maxDeviceCount = 4,
        .i2cEnabled = true,
        .spiEnabled = true,
        .uartEnabled = false
    },
    .screen = ScreenConfiguration{
        .i2cAddress = "0x3C",
        .widthPx = 128,
        .heightPx = 64
    },
    .dios = {
        { .name = "DIO0" },
        { .name = "DIO1" }
    },
    .aios = {
        { .name = "AIO0" },
        { .name = "AIO1" }
    }
};