#pragma once
#include <cstdint>

enum class Animation : uint8_t {
    None,
    Fill,
    Blink,
    Breathe,
    RainbowFade,
    SineRoll,
    Chase
};