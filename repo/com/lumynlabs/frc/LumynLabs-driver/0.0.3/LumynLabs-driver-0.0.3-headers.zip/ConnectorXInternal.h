#pragma once

#include <iostream>
#include <functional>
#include "networking/ConnectorXHandler.h"
#include "networking/TransmissionPortListener.h"
#include "ConnectorXInternal.h"
#include <hal/SerialPort.h>

namespace lumyn::internal
{

        void doThing();

        class ConnectorXInternal
        {
        public:
                ConnectorXInternal();
                ~ConnectorXInternal();

                void Initialize(HAL_SerialPort);

        private:
                ConnectorXHandler _connectorXHandler;
                TransmissionPortListener _transmissionPortListener{std::make_shared<ConnectorXHandler>()};
        };

        ConnectorXInternal* getConnectorXInternalInstance();
        void initializeConnectorXinternal(ConnectorXInternal* connectorXInternal, HAL_SerialPort port);

#ifdef __cplusplus
        extern "C"
        {
#endif
                void c_doThing();
                ConnectorXInternal* c_getConnectorXInternalInstance();
                void c_initializeConnectorXinternal(ConnectorXInternal* connectorXInternal, HAL_SerialPort port);
#ifdef __cplusplus
        } // extern "C"
#endif
}
