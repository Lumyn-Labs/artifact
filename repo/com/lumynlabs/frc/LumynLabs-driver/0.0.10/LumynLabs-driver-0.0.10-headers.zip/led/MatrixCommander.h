#pragma once

#include "domain/command/led/LEDCommand.h"
#include "./Animation.h"

#include <units/time.h>
#include <functional>

namespace lumyn::internal
{
  class MatrixCommander
  {
  public:
    MatrixCommander(std::function<void(Command::LED::LEDCommand &)> handler) : _cmdHandler{handler} {}

    Command::LED::LEDCommand SetBitmap(std::string_view, std::string_view, Command::LED::AnimationColor,
                                       bool setColor = false, bool oneShot = false);
    Command::LED::LEDCommand SetGroupBitmap(std::string_view, std::string_view, Command::LED::AnimationColor,
                                            bool setColor = false, bool oneShot = false);
    Command::LED::LEDCommand SetText(std::string_view, std::string_view, Command::LED::AnimationColor,
                                     Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                                     units::millisecond_t delayMs = 500_ms, bool oneShot = false);
    Command::LED::LEDCommand SetGroupText(std::string_view, std::string_view, Command::LED::AnimationColor,
                                          Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                                          units::millisecond_t delayMs = 500_ms, bool oneShot = false);

  private:
    std::function<void(Command::LED::LEDCommand &)> _cmdHandler;
  };
}