#pragma once

#include "./BaseConnectorXVariant.h"
#include "modules/ModulesManager.h"
#include "led/LEDCommander.h"
#include "led/MatrixCommander.h"

namespace lumyn::internal
{
  class ConnectorX : public BaseConnectorXVariant
  {
  public:
    ConnectorX() : BaseConnectorXVariant()
    {
      _leds = std::make_unique<LEDCommander>(std::bind(&ConnectorX::SendLEDCommand, this, std::placeholders::_1));
      _matrix = std::make_unique<MatrixCommander>(std::bind(&ConnectorX::SendLEDCommand, this, std::placeholders::_1));
    }

    // TODO: Add the variant definition

    void SetEventCallback(std::function<void(const Eventing::Event &)> handler)
    {
      _eventHandler = handler;
    }

    ModulesManager &modules()
    {
      return _modules;
    }

    LEDCommander &leds()
    {
      return *_leds;
    }

    MatrixCommander &matrix()
    {
      return *_matrix;
    }

  protected:
    void HandleNewModuleData(const ModuleData::ModuleData &data) override;
    void HandleEvent(const Eventing::Event &) override;

  private:
    void SendLEDCommand(Command::LED::LEDCommand &ledCmd)
    {
      Command::Command cmd = {
          .type = Command::APIGroupType::LED,
          .led = ledCmd};
      _portListener->SendCommand(cmd);
    }

    std::function<void(const Eventing::Event &)> _eventHandler;
    ModulesManager _modules;
    std::unique_ptr<LEDCommander> _leds;
    std::unique_ptr<MatrixCommander> _matrix;
  };
}