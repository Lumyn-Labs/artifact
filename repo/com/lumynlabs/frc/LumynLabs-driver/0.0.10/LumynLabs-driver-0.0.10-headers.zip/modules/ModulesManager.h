#pragma once

#include "domain/module/ModuleData.h"

#include <string_view>
#include <optional>
#include <functional>
#include <unordered_map>

namespace lumyn::internal
{
  typedef void (*ModuleDataCallback_t)(const ModuleData::NewDataInfo *);

  class ModulesManager
  {
  public:
    uint16_t RegisterModule(std::string_view moduleID, std::function<void(const ModuleData::NewDataInfo &)>);
    void Extract(const ModuleData::NewDataInfo &, void *);
    bool GetLatestData(std::string_view moduleID, void *);
    void AddDataEntry(const ModuleData::NewDataInfo);

  private:
    // Maps a module by ID to the latest data and its corresponding callback
    std::unordered_map<uint16_t, std::pair<std::optional<ModuleData::NewDataInfo>,
                                           std::function<void(const ModuleData::NewDataInfo &)>>>
        _modules;
  };
}