#pragma once

#include "ModuleDataType.h"
#include "packed.h"

namespace lumyn::internal::ModuleData
{
  PACK(struct NewDataInfo {
    uint16_t id;
    uint8_t data[16];
    uint8_t len;
  });

  PACK(struct ModuleData {
    ModuleDataType type;
    union
    {
      NewDataInfo newData;
    };
  });
} // namespace lumyn::internal::ModuleData