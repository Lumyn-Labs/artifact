#pragma once

#include <iostream>
#include "ILumynTransmissionHandler.h"

namespace lumyn::internal
{
    class ConnectorXHandler : public ILumynTransmissionHandler
    {
    public:
        ConnectorXHandler() = default;
        ~ConnectorXHandler() = default;

        void HandleEvent(const Eventing::Event &event) override;
        void HandleModuleData(const ModuleData::ModuleData &moduleData) override;
        void HandleTransmission(const Transmission::Transmission &transmission) override;

    private:
        std::vector<Eventing::Event> _events;
    };
} // namespace lumyn::internal