#pragma once

#include "LEDCommandType.h"
#include "packed.h"

namespace lumyn::internal::Command
{
  namespace LED
  {
    struct AnimationColor
    {
      uint8_t r;
      uint8_t g;
      uint8_t b;
    };

    struct SetAnimationData
    {
      uint16_t zoneId;
      uint16_t animationId;
      uint16_t delay;
      AnimationColor color;
      uint8_t reversed : 1;
      uint8_t oneShot : 1;
    };

    struct SetAnimationGroupData
    {
      uint16_t groupId;
      uint16_t animationId;
      uint16_t delay;
      AnimationColor color;
      uint8_t reversed : 1;
      uint8_t oneShot : 1;
    };

    struct SetColorData
    {
      uint16_t zoneId;
      AnimationColor color;
    };

    struct SetColorGroupData
    {
      uint16_t groupId;
      AnimationColor color;
    };

    struct SetAnimationSequenceData
    {
      uint16_t zoneId;
      uint16_t sequenceId;
    };

    struct SetAnimationSequenceGroupData
    {
      uint16_t groupId;
      uint16_t sequenceId;
    };

    struct SetBitmapData
    {
      uint16_t zoneId;
      uint16_t bitmapId;
      AnimationColor color;
      uint8_t setColor : 1;
      uint8_t oneShot : 1;
    };

    struct SetBitmapGroupData
    {
      uint16_t groupId;
      uint16_t bitmapId;
      AnimationColor color;
      uint8_t setColor : 1;
      uint8_t oneShot : 1;
    };

    enum class MatrixTextScrollDirection : uint8_t { LEFT = 0, RIGHT };

    PACK(struct SetMatrixTextData
    {
      uint16_t zoneId;
      uint8_t oneShot;
      AnimationColor color;
      MatrixTextScrollDirection dir;
      char text[24];
      uint8_t length;
      uint16_t delay;
    });

    PACK(struct SetMatrixTextGroupData
    {
      uint16_t groupId;
      uint8_t oneShot;
      AnimationColor color;
      MatrixTextScrollDirection dir;
      char text[24];
      uint8_t length;
      uint16_t delay;
    });

    PACK(struct LEDCommand {
      LEDCommandType type;
      union
      {
        SetAnimationData setAnimation;
        SetAnimationGroupData setAnimationGroup;
        SetColorData setColor;
        SetColorGroupData setColorGroup;
        SetAnimationSequenceData setAnimationSequence;
        SetAnimationSequenceGroupData setAnimationSequenceGroup;
        SetBitmapData setBitmap;
        SetBitmapGroupData setBitmapGroup;
        SetMatrixTextData setMatrixText;
        SetMatrixTextGroupData setMatrixTextGroup;
      };
    });

    constexpr auto sz = sizeof(LEDCommand);
  } // namespace LED
} // namespace Command