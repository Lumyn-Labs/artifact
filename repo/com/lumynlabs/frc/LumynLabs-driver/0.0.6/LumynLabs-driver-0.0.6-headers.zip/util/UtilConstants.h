#pragma once

namespace lumyn
{
    namespace Logging
    {
        /**
         * @brief Levels of logging
         *
         */
        enum class Level
        {
            VERBOSE = 0,
            INFO,
            WARNING,
            ERROR,
            FATAL
        };
        /**
         * @brief Will not log messages that fall below this level
         *
         */
        constexpr auto kMinLogLevel = Level::VERBOSE;

        /**
         * @brief Logging prefix
         */
        constexpr auto kLogPrefix = "[  Lumyn   ] ";
    } // namespace Logging

} // namespace lumyn
