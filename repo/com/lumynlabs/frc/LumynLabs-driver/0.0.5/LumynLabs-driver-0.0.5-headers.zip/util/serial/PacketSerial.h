#pragma once

#include <iostream>
#include <functional>
#include "domain/transmission/Transmission.h"
#include "domain/transmission/Packet.h"
#include "util/serial/IEncoder.h"
#include <hal/Types.h>
#include <thread>
#include <atomic>

namespace lumyn::internal
{

    class PacketSerial
    {
    public:
        PacketSerial(IEncoder *encoder, int port, int bufferSize = 4096);

        ~PacketSerial();

        void startReading();
        void stopReading();

        void send(Packet &packet);

        void setOnOverflow(std::function<void()> onOverflow)
        {
            this->onOverflow = onOverflow;
        }

        void setOnPacketOverflow(std::function<void()> onPacketOverflow)
        {
            this->onPacketOverflow = onPacketOverflow;
        }

        void setOnNewPacket(std::function<void(Packet&, int)> onNewPacket)
        {
            this->onNewPacket = onNewPacket;
        }

    private:
        IEncoder *_encoder;
        uint8_t _port;
        uint8_t _buffer[MAX_PACKET_SIZE];
        size_t _receiveBufferIndex;
        uint8_t _receiveReadIndex;
        uint8_t* _tmpPacketBuffer;
        size_t _tmpPacketIndex;
        uint8_t _readBuffer[MAX_PACKET_SIZE];
        HAL_SerialPortHandle _portHandle;

        std::function<void()> onOverflow;
        std::function<void()> onPacketOverflow;
        std::function<void(Packet&, int)> onNewPacket;

        std::thread _readThread;
        std::atomic<bool> _reading;
    };
} // namespace lumyn::internal