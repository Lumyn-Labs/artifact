#pragma once

#include <functional>
#include "domain/event/Event.h"
#include "domain/response/Response.h"
#include "domain/module/ModuleData.h"
#include "domain/transmission/Transmission.h"

namespace lumyn::internal
{
    class ILumynTransmissionHandler
    {
    public:
        virtual ~ILumynTransmissionHandler() = default;

        virtual void HandleEvent(const Eventing::Event &) = 0;
        virtual void HandleModuleData(const ModuleData::ModuleData &) = 0;
        virtual void HandleTransmission(const Transmission::Transmission &) = 0;
    };
}
