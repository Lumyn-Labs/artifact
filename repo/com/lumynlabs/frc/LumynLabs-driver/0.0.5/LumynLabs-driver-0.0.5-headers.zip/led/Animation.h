#pragma once
#include <cinttypes>

enum class Animation : uint8_t {
    None,
    Fill,
    Blink,
    Breathe,
    RainbowFade,
    SineRoll,
    Chase
};