#pragma once

#include "domain/command/CommandType.h"
#include "packed.h"

namespace Command {
PACK(struct Command {
  APIGroupType type;
  union {
    LED::LEDCommand led;
    System::SystemCommand system;
  };
});
};  // namespace Command