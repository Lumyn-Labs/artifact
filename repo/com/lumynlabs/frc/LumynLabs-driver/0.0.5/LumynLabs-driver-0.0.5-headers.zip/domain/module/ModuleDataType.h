#pragma once

#include <stdint.h>

namespace ModuleData {
enum class ModuleDataType : uint8_t { NewData = 0 };
}  // namespace ModuleData