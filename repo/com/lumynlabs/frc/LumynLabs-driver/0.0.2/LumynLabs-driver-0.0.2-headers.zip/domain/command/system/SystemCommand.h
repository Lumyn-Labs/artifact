#pragma once

#include "SystemCommandType.h"
#include <cstdint>

namespace Command {
namespace System {
struct ClearStatusFlagData {
  uint32_t mask;
};

struct __attribute__((packed)) SystemCommand {
  SystemCommandType type;
  union {
    ClearStatusFlagData clearStatusFlag;
  };
};
}  // namespace System
}  // namespace Command