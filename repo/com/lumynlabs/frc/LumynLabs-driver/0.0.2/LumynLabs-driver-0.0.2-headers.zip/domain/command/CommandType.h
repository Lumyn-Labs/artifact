#pragma once

#include <cstdint>

#include "domain/command/led/LEDCommand.h"
#include "domain/command/system/SystemCommand.h"

namespace Command {
// 8-bit identifier for API grouping
enum class APIGroupType : uint8_t {
  System,
  LED,
  Device,
};
}  // namespace Command