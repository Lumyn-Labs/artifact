#pragma once

#include "domain/command/CommandType.h"

namespace Command {
struct Command {
  APIGroupType type : 6;
  union {
    LED::LEDCommand led;
    System::SystemCommand system;
  };
};
};  // namespace Command