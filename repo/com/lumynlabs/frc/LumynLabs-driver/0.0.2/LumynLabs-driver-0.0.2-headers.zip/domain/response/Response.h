#pragma once

#include "domain/event/Event.h"
#include "domain/request/RequestType.h"

namespace Response {
struct ResponseStatusInfo {
  // TODO: Global status enum
};
struct ResponseProductSKUInfo {
  uint16_t sku;
};
struct ResponseProductSerialNumberInfo {
  uint32_t serialNumber;
};
struct ResponseConfigHashInfo {
  uint8_t hash[8];
};
struct ResponseFaultsInfo {
  uint32_t faultFlags;
};
struct ResponseDeviceStatusInfo {
  uint16_t deviceId;
  uint8_t status;
};
struct ResponseDeviceDataInfo {
  uint16_t deviceId;
  // TODO: constant for max data size
  uint8_t data[16];
  uint8_t length;
};
struct ResponseLEDChannelStatusInfo {
  uint16_t channelId;
};
struct ResponseLEDZoneStatusInfo {
  uint16_t zoneId;
};
struct ResponseLatestEventInfo {
  Eventing::EventType eventType;
};
struct ResponseEventFlagsInfo {
  uint32_t eventFlags;
};

struct Response {
  Request::RequestType type;
  union {
    ResponseStatusInfo status;
    ResponseProductSKUInfo productSku;
    ResponseProductSerialNumberInfo productSerialNumber;
    ResponseConfigHashInfo configHash;
    ResponseFaultsInfo faults;
    ResponseDeviceStatusInfo deviceStatus;
    ResponseDeviceDataInfo deviceData;
    ResponseLEDChannelStatusInfo ledChannelStatus;
    ResponseLEDZoneStatusInfo ledZoneStatus;
    ResponseLatestEventInfo latestEvent;
    ResponseEventFlagsInfo eventFlags;
  };
};
}  // namespace Response