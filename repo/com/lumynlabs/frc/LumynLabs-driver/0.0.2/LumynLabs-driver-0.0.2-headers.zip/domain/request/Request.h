#pragma once

#include "RequestType.h"

namespace Request {
struct RequestStatusInfo {};
struct RequestProductSKUInfo {};
struct RequestProductSerialNumberInfo {};
struct RequestConfigHashInfo {};
struct RequestFaultsInfo {};
struct RequestDeviceStatusInfo {
  uint16_t deviceId;
};
struct RequestDeviceDataInfo {
  uint16_t deviceId;
};
struct RequestLEDChannelStatusInfo {
  uint16_t channelId;
};
struct RequestLEDZoneStatusInfo {
  uint16_t zoneId;
};
struct RequestLatestEventInfo {};
struct RequestEventFlagsInfo {};

struct Request {
  RequestType type;
  union {
    RequestStatusInfo status;
    RequestProductSKUInfo productSku;
    RequestProductSerialNumberInfo productSerialNumber;
    RequestConfigHashInfo configHash;
    RequestFaultsInfo faults;
    RequestDeviceStatusInfo deviceStatus;
    RequestDeviceDataInfo deviceData;
    RequestLEDChannelStatusInfo ledChannelStatus;
    RequestLEDZoneStatusInfo ledZoneStatus;
    RequestLatestEventInfo latestEvent;
    RequestEventFlagsInfo eventFlags;
  };
};
}  // namespace Request