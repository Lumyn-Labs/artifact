#pragma once

#include <memory>
#include <vector>

#include "domain/transmission/TransmissionType.h"

namespace Transmission {

struct TransmissionHeader {
  TransmissionType type;
};

struct TransmissionBody {
  // ! MUST CALL DELETE WHEN RECEIVING FROM A QUEUE
  std::vector<uint8_t> data;
};

struct Transmission {
  TransmissionHeader header;
  TransmissionBody body;
};
}  // namespace Transmission