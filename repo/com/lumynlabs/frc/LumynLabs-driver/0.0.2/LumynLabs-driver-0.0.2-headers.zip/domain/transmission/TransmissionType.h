#pragma once

namespace Transmission {
enum class TransmissionType : uint8_t {
  Handshake = 0,
  Request,
  Response,
  Event,
  Config,
  Command
};
}  // namespace Transmission