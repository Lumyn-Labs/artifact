#pragma once
#include <cstdint>

namespace Request {
  enum class RequestType : uint8_t {
    Status,
    ProductSKU,
    ProductSerialNumber,
    ConfigHash,
    Faults,
    DeviceStatus,
    DeviceData,
    LEDChannelStatus,
    LEDZoneStatus,
    LatestEvent,
    EventFlags,
  };
};