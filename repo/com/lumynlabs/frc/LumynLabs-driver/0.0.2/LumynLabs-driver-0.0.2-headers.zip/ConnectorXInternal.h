#pragma once

#include "domain/transmission/Transmission.h"

namespace lumyn
{
    namespace internal
    {
        Transmission::Transmission doThing();

#ifdef __cplusplus
        extern "C"
        {
#endif

            void c_doThing();

#ifdef __cplusplus
        } // extern "C"
#endif
    }
}
