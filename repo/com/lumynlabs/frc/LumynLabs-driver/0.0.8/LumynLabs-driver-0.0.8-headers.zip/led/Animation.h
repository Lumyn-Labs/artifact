#pragma once
#include <cinttypes>

namespace lumyn::led
{
    enum class Animation : uint16_t
    {
        None,
        Fill,
        Blink,
        Breathe,
        RainbowFade,
        SineRoll,
        Chase
    };
} // namespace lumyn::led