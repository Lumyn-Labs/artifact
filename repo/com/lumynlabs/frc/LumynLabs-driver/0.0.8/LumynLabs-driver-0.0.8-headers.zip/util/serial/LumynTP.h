#pragma once

#include <iostream>
#include <functional>
#include "domain/transmission/Transmission.h"
#include "domain/transmission/Packet.h"
#include "PacketSerial.h"

namespace lumyn::internal
{

    class LumynTP
    {
    public:
        LumynTP(PacketSerial &packetSerial) : _packetSerial(packetSerial),
                                              _lastPacketId(-1)
        {
            _packetSerial.setOnNewPacket([this](Packet &packet)
                                         { this->handlePacket(packet); });
        }

        void start();
        void sendTransmission(const uint8_t *data, size_t dataLength, Transmission::TransmissionType type);
        void setOnNewTransmission(std::function<void(Transmission::Transmission *)> onNewTransmission)
        {
            this->onNewTransmission = onNewTransmission;
        }

    private:
        void handlePacket(Packet &packet);
        PacketSerial &_packetSerial;
        uint8_t _transmissionBuffer[256];
        std::function<void(Transmission::Transmission *)> onNewTransmission;
        uint16_t _lastPacketId;
        Transmission::Transmission _currentTransmission;
    };
} // namespace lumyn::internal