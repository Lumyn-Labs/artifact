#pragma once

#include <cinttypes>

#include "SystemCommandType.h"
#include "packed.h"

namespace lumyn::internal::Command
{
  namespace System
  {
    struct ClearStatusFlagData
    {
      uint32_t mask;
    };

    PACK(struct SetAssignedIdData {
      char id[24];
    });

    PACK(struct SystemCommand {
      SystemCommandType type;
      union
      {
        ClearStatusFlagData clearStatusFlag;
        SetAssignedIdData assignedId;
      };
    });
  } // namespace System
} // namespace Command