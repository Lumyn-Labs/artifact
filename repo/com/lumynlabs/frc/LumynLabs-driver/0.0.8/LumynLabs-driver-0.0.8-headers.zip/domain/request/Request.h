#pragma once

#include <cinttypes>

#include "RequestType.h"
#include "packed.h"

namespace lumyn::internal::Request
{
  PACK(struct RequestHandshakeInfo {
    HostConnectionSource hostSource;
  });
  PACK(struct RequestStatusInfo{});
  PACK(struct RequestProductSKUInfo{});
  PACK(struct RequestProductSerialNumberInfo{});
  PACK(struct RequestConfigHashInfo{});
  PACK(struct RequestAssignedIdInfo{});
  PACK(struct RequestFaultsInfo{});
  PACK(struct RequestDeviceStatusInfo {
    uint16_t deviceId;
  });
  PACK(struct RequestDeviceDataInfo {
    uint16_t deviceId;
  });
  PACK(struct RequestLEDChannelStatusInfo {
    uint16_t channelId;
  });
  PACK(struct RequestLEDZoneStatusInfo {
    uint16_t zoneId;
  });
  PACK(struct RequestLatestEventInfo{});
  PACK(struct RequestEventFlagsInfo{});

  PACK(struct Request {
    RequestType type;
    // Randomized request ID to correlate with the Response
    uint32_t id;
    union
    {
      RequestHandshakeInfo handshake;
      RequestStatusInfo status;
      RequestProductSKUInfo productSku;
      RequestProductSerialNumberInfo productSerialNumber;
      RequestConfigHashInfo configHash;
      RequestAssignedIdInfo assignedId;
      RequestFaultsInfo faults;
      RequestDeviceStatusInfo deviceStatus;
      RequestDeviceDataInfo deviceData;
      RequestLEDChannelStatusInfo ledChannelStatus;
      RequestLEDZoneStatusInfo ledZoneStatus;
      RequestLatestEventInfo latestEvent;
      RequestEventFlagsInfo eventFlags;
    };
  });
} // namespace lumyn::internal::Request