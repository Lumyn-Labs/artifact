#pragma once

#include "domain/command/CommandType.h"
#include "packed.h"

namespace lumyn::internal::Command
{
  PACK(struct Command {
    APIGroupType type;
    union
    {
      LED::LEDCommand led;
      System::SystemCommand system;
    };
  });
}; // namespace lumyn::internal::Command