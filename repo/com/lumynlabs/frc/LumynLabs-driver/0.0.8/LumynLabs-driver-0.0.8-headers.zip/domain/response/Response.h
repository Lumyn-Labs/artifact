#pragma once

#include "domain/event/Event.h"
#include "domain/request/RequestType.h"
#include "packed.h"

namespace lumyn::internal
{

  // needed because in firmware this is included from outside the domain
  namespace SystemStatus
  {
    enum class Status : uint8_t
    {
      Booting = 0,
      Active,
      Error,
      Fatal
    };
  } // namespace SystemStatus

  namespace Response
  {
    PACK(struct ResponseStatusInfo {
      SystemStatus::Status status;
    });
    PACK(struct ResponseProductSKUInfo {
      uint16_t sku;
    });
    PACK(struct ResponseProductSerialNumberInfo {
      uint64_t serialNumber;
    });
    PACK(struct ResponseConfigHashInfo {
      uint8_t hash[16];
    });
    PACK(struct ResponseAssignedIdInfo {
      uint8_t valid;
      char id[24];
    });
    PACK(struct ResponseHandshakeInfo {
      ResponseStatusInfo status;
      ResponseProductSKUInfo sku;
      ResponseProductSerialNumberInfo serNumber;
      ResponseConfigHashInfo configHash;
      ResponseAssignedIdInfo assignedId;
    });
    PACK(struct ResponseFaultsInfo {
      uint32_t faultFlags;
    });
    PACK(struct ResponseDeviceStatusInfo {
      uint16_t deviceId;
      uint8_t status;
    });
    PACK(struct ResponseDeviceDataInfo {
      uint16_t deviceId;
      // TODO: constant for max data size
      uint8_t data[16];
      uint8_t length;
    });
    PACK(struct ResponseLEDChannelStatusInfo {
      uint16_t channelId;
    });
    PACK(struct ResponseLEDZoneStatusInfo {
      uint16_t zoneId;
    });
    PACK(struct ResponseLatestEventInfo {
      Eventing::EventType eventType;
    });
    PACK(struct ResponseEventFlagsInfo {
      uint32_t eventFlags;
    });

    PACK(struct Response {
      Request::RequestType type;
      // Should match the incoming Request's ID
      uint32_t id;
      union
      {
        ResponseHandshakeInfo handshake;
        ResponseStatusInfo status;
        ResponseProductSKUInfo productSku;
        ResponseProductSerialNumberInfo productSerialNumber;
        ResponseConfigHashInfo configHash;
        ResponseAssignedIdInfo assignedId;
        ResponseFaultsInfo faults;
        ResponseDeviceStatusInfo deviceStatus;
        ResponseDeviceDataInfo deviceData;
        ResponseLEDChannelStatusInfo ledChannelStatus;
        ResponseLEDZoneStatusInfo ledZoneStatus;
        ResponseLatestEventInfo latestEvent;
        ResponseEventFlagsInfo eventFlags;
      };
    });

    constexpr auto sz = sizeof(Response);
  } // namespace Response

} // namespace lumyn::internal