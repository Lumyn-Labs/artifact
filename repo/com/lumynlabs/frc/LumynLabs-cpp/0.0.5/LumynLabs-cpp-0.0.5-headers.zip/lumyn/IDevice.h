#pragma once
#include "units/time.h"

#include "device/DeviceDefinition.h"

namespace lumyn
{

    class IDevice
    {
    public:

        bool IsConnected(units::second_t timeout = 1_s);

        virtual inline std::string GetDeviceClassName() { return "LumynDevice"; }

    protected:
        DeviceDefinition m_deviceDefinition;
    };
}