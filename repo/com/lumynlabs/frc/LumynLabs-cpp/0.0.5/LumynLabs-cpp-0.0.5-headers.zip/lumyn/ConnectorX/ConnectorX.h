#pragma once

#include "ConnectorXInternal.h"
#include <iostream>
#include "lumyn/IDevice.h"
#include "led/Animation.h"
#include <hal/SerialPort.h>

#include <frc/util/Color.h>

namespace lumyn
{
    namespace ConnectorX
    {
        class ConnectorX : public IDevice
        {
        public:
            ConnectorX(HAL_SerialPort port) : IDevice()
            {
                m_deviceDefinition = {
                    .info = {
                        .id = "cx",
                        .name = "ConnectorX",
                        .version = "3.1.0a",
                        .productUrl = "https://shop.lumynlabs.com/connectorx",
                        .productImgUrl = "/product_imgs/connector-x.jpg",
                        .usbVendorId = "",
                        .usbProductId = "",
                        .usbDebugProductId = "",
                        .regulatorOutputMa = 4000,
                        .supportedCommunication = {CommunicationType::USB, CommunicationType::I2C, CommunicationType::UART}},
                    .features = {.enableLEDs = true, .enableDevices = true, .enableScreen = true, .enableMic = false, .enableDIO = true, .enableAIO = true},
                    .led = LEDConfiguration{.ledPowerDrawMa = 60, .channelCount = 4},
                    .devices = DeviceConfiguration{.maxDeviceCount = 4, .i2cEnabled = true, .spiEnabled = true, .uartEnabled = false},
                    .screen = ScreenConfiguration{.i2cAddress = "0x3C", .widthPx = 128, .heightPx = 64},
                    .dios = {{.name = "DIO0"}, {.name = "DIO1"}},
                    .aios = {{.name = "AIO0"}, {.name = "AIO1"}}};

                _port = port;

                Initialize();
            }

            // TODO: Remove this, test function
            void vendorFunction();

            std::string GetDeviceClassName() override { return "ConnectorX"; };

            // Set all LEDs on a zone to a color, mirrors WPI way of setting LEDs
            // Should have the same result as SetAnimation(fill, zone, color)
            void SetColor(std::string_view zoneID, frc::Color color);
            void SetGroupColor(std::string_view groupID, frc::Color color);

            void SetAnimation(Animation animation, std::string_view zoneID, frc::Color color, units::second_t delay = 0_s, bool reversed = 0, bool oneShot = 0);
            void SetGroupAnimation(Animation animation, std::string_view groupID, frc::Color color, units::second_t delay = 0_s, bool reversed = 0, bool oneShot = 0);

            void SetBitmap(std::string_view zoneID, std::string_view bitmapID, frc::Color color, bool setColor = 0, bool oneShot = 0);
            void SetGroupBitmap(std::string_view groupID, std::string_view bitmapID, frc::Color color, bool setColor = 0, bool oneShot = 0);

            void SetAnimationSequence(std::string_view sequenceID, std::string_view zoneID);
            void SetGroupAnimationSequence(std::string_view sequenceID, std::string_view groupID);

        private:
            void Initialize();

            lumyn::internal::ConnectorXInternal *_connectorXInternal;
            HAL_SerialPort _port;
        };
    }
}