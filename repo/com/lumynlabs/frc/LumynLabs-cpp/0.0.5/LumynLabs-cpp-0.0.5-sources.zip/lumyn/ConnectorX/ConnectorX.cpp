#include "lumyn/ConnectorX/ConnectorX.h"

void lumyn::ConnectorX::ConnectorX::Initialize()
{
    // Create connection to the device
    // Send handshake
    // throw errors if vendordep version doesn't match device
    // etc.

    _connectorXInternal = lumyn::internal::c_getConnectorXInternalInstance();
    lumyn::internal::c_initializeConnectorXinternal(_connectorXInternal, HAL_SerialPort_USB1);
}

void lumyn::ConnectorX::ConnectorX::vendorFunction()
{
    lumyn::internal::c_doThing();
    std::cout << "Hello from the vendor library!";
}

void lumyn::ConnectorX::ConnectorX::SetColor(std::string_view zoneID, frc::Color color)
{
}

void lumyn::ConnectorX::ConnectorX::SetGroupColor(std::string_view groupID, frc::Color color)
{
}

void lumyn::ConnectorX::ConnectorX::SetAnimation(Animation animation, std::string_view zoneID, frc::Color color, units::second_t delay, bool reversed, bool oneShot)
{
}

void lumyn::ConnectorX::ConnectorX::SetGroupAnimation(Animation animation, std::string_view groupID, frc::Color color, units::second_t delay, bool reversed, bool oneShot)
{
}

void lumyn::ConnectorX::ConnectorX::SetBitmap(std::string_view zoneID, std::string_view bitmapID, frc::Color color, bool setColor, bool oneShot)
{
}

void lumyn::ConnectorX::ConnectorX::SetGroupBitmap(std::string_view groupID, std::string_view bitmapID, frc::Color color, bool setColor, bool oneShot)
{
}

void lumyn::ConnectorX::ConnectorX::SetAnimationSequence(std::string_view sequenceID, std::string_view zoneID)
{
}

void lumyn::ConnectorX::ConnectorX::SetGroupAnimationSequence(std::string_view sequenceID, std::string_view groupID)
{
}