#include "lumyn/device/ConnectorX.h"

using namespace lumyn::internal::c_ConnectorX;

void lumyn::device::ConnectorX::SetColor(std::string_view zoneID, frc::Color color)
{
  auto animationColor = ColorToRGB(color);
  cx_SetColor(_connectorXInternal, zoneID.data(), animationColor);
}

void lumyn::device::ConnectorX::SetGroupColor(std::string_view groupID, frc::Color color)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupColor(_connectorXInternal, groupID.data(), animationColor);
}

void lumyn::device::ConnectorX::SetAnimation(lumyn::led::Animation animation, std::string_view zoneID, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetAnimation(_connectorXInternal, zoneID.data(), animation, animationColor, delay, reversed, oneShot);
}

void lumyn::device::ConnectorX::SetGroupAnimation(lumyn::led::Animation animation, std::string_view groupID, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupAnimation(_connectorXInternal, groupID.data(), animation, animationColor, delay, reversed, oneShot);
}

void lumyn::device::ConnectorX::SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID)
{
  cx_SetAnimationSequence(_connectorXInternal, zoneID.data(), sequenceID.data());
}

void lumyn::device::ConnectorX::SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID)
{
  cx_SetGroupAnimationSequence(_connectorXInternal, groupID.data(), sequenceID.data());
}

void lumyn::device::ConnectorX::SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetBitmap(_connectorXInternal, zoneID.data(), sequenceID.data(), animationColor, setColor, oneShot);
}

void lumyn::device::ConnectorX::SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetBitmap(_connectorXInternal, groupID.data(), sequenceID.data(), animationColor, setColor, oneShot);
}
