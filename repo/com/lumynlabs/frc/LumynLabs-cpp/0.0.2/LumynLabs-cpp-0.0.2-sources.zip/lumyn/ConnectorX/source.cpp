#include "lumyn/ConnectorX/ConnectorX.h"

namespace lumyn
{
    namespace ConnectorX
    {
        void vendorFunction()
        {
            lumyn::internal::c_doThing();
            std::cout << "Hello from the vendor library!";
        }
    }
}