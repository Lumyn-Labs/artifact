#include "ConnectorXInternal.h"
#include <iostream>

namespace lumyn
{
    namespace ConnectorX
    {
        void vendorFunction();
    }
}