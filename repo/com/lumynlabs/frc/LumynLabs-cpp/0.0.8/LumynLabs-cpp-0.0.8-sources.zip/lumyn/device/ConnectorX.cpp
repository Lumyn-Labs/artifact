#include "lumyn/device/ConnectorX.h"
#include <frc/util/Color8Bit.h>

void lumyn::device::ConnectorX::vendorFunction()
{
    lumyn::internal::c_doThing();
    std::cout << "Hello from the vendor library!";
}

void lumyn::device::ConnectorX::SetColor(std::string_view zoneID, frc::Color color)
{
}

void lumyn::device::ConnectorX::SetGroupColor(std::string_view groupID, frc::Color color)
{
}

void lumyn::device::ConnectorX::SetAnimation(lumyn::led::Animation animation, std::string_view zoneID, frc::Color color, units::second_t delay, bool reversed, bool oneShot)
{
    AnimationColor animationColor = ColorToRGB(color);
    c_CXISetAnimation(_connectorXInternal, animation, zoneID, {.r = animationColor.r, .g = animationColor.g, .b = animationColor.b}, delay, reversed, oneShot);
}

void lumyn::device::ConnectorX::SetGroupAnimation(lumyn::led::Animation animation, std::string_view groupID, frc::Color color, units::second_t delay, bool reversed, bool oneShot)
{
}

void lumyn::device::ConnectorX::SetBitmap(std::string_view zoneID, std::string_view bitmapID, frc::Color color, bool setColor, bool oneShot)
{
}

void lumyn::device::ConnectorX::SetGroupBitmap(std::string_view groupID, std::string_view bitmapID, frc::Color color, bool setColor, bool oneShot)
{
}

void lumyn::device::ConnectorX::SetAnimationSequence(std::string_view sequenceID, std::string_view zoneID)
{
}

void lumyn::device::ConnectorX::SetGroupAnimationSequence(std::string_view sequenceID, std::string_view groupID)
{
}