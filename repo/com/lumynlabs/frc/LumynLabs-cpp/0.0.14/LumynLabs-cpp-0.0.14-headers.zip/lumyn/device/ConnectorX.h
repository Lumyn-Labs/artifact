#pragma once

#include <hal/SerialPort.h>
#include <frc/util/Color8Bit.h>
#include <units/time.h>

#include "led/Animation.h"
#include "connectorXVariant/c_ConnectorX.h"

#include <iostream>

namespace lumyn
{
  namespace device
  {
    class ConnectorX
    {
    public:
      ConnectorX()
      {
        _connectorXInternal = lumyn::internal::c_ConnectorX::cx_CreateInstance();
      }

      ~ConnectorX()
      {
        if (_connectorXInternal)
        {
          delete _connectorXInternal;
          _connectorXInternal = nullptr;
        }
      }

      ConnectorX(const ConnectorX &other) = delete;
      ConnectorX(ConnectorX &&other) = delete;
      ConnectorX &operator=(const ConnectorX &other) = delete;
      ConnectorX &operator=(ConnectorX &&other) = delete;

      void Connect(HAL_SerialPort port);
      bool IsConnected(void);
      lumyn::internal::Eventing::Status GetCurrentStatus(void);
      std::optional<lumyn::internal::Eventing::Event> GetLatestEvent(void);
      void SetEventCallback(std::function<void(const lumyn::internal::Eventing::Event &)> cb);

      void RegisterModule(std::string_view moduleID, std::function<void(const lumyn::internal::ModuleData::NewDataInfo &)> cb);

      template <typename T>
      T ExtractFromPayload(lumyn::internal::ModuleData::NewDataInfo *data)
      {
        T payload;
        lumyn::internal::c_ConnectorX::cx_ExtractData(_connectorXInternal, data, &payload);

        return payload;
      }

      template <typename T>
      std::optional<T> GetLatestData(std::string_view moduleID)
      {
        T payload;

        if (lumyn::internal::c_ConnectorX::cx_GetLatestData(_connectorXInternal, moduleID.data(), &payload))
        {
          return payload;
        }

        return std::nullopt;
      }

      // Set all LEDs on a zone to a color, mirrors WPI way of setting LEDs
      // Should have the same result as SetAnimation(fill, zone, color)
      void SetColor(std::string_view zoneID, frc::Color color);
      void SetGroupColor(std::string_view groupID, frc::Color color);

      void SetAnimation(std::string_view zoneID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay = 250_ms, bool reversed = false, bool oneShot = false);
      void SetGroupAnimation(std::string_view groupID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay = 250_ms, bool reversed = false, bool oneShot = false);

      void SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID);
      void SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID);

      void SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color, bool setColor = false, bool oneShot = false);
      void SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color, bool setColor = false, bool oneShot = false);

      void SetMatrixText(std::string_view zoneID, std::string_view text, frc::Color color,
        lumyn::internal::Command::LED::MatrixTextScrollDirection direction = lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT,
        units::millisecond_t delayMs = 500_ms, bool oneShot = false);
      void SetGroupMatrixText(std::string_view groupID, std::string_view text, frc::Color color,
        lumyn::internal::Command::LED::MatrixTextScrollDirection direction = lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT,
        units::millisecond_t delayMs = 500_ms, bool oneShot = false);

    private:
      inline lumyn::internal::Command::LED::AnimationColor ColorToRGB(const frc::Color &color)
      {
        return {
            .r = static_cast<uint8_t>(color.red * 255),
            .g = static_cast<uint8_t>(color.green * 255),
            .b = static_cast<uint8_t>(color.blue * 255)};
      }

      lumyn::internal::c_ConnectorX::ConnectorX_int *_connectorXInternal;
      HAL_SerialPort _port;
    };
  }
}