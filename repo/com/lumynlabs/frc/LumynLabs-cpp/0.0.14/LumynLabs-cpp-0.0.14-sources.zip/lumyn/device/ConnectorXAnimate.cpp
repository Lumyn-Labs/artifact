#include "lumyn/device/ConnectorXAnimate.h"

using namespace lumyn::internal::c_ConnectorX;

void lumyn::device::ConnectorXAnimate::Connect(HAL_SerialPort port)
{
  _port = port;
  cx_Connect(_connectorXInternal, port);
}

bool lumyn::device::ConnectorXAnimate::IsConnected()
{
  return cx_IsConnected(_connectorXInternal);
}

lumyn::internal::Eventing::Status lumyn::device::ConnectorXAnimate::GetCurrentStatus()
{
  return cx_GetCurrentStatus(_connectorXInternal);
}

std::optional<lumyn::internal::Eventing::Event> lumyn::device::ConnectorXAnimate::GetLatestEvent()
{
  lumyn::internal::Eventing::Event evt;

  if (cx_GetLatestEvent(_connectorXInternal, &evt))
  {
    return evt;
  }

  return std::nullopt;
}

void lumyn::device::ConnectorXAnimate::SetEventCallback(std::function<void(const lumyn::internal::Eventing::Event &)> cb)
{
  cx_SetEventCallback(_connectorXInternal, cb);
}

void lumyn::device::ConnectorXAnimate::SetColor(std::string_view zoneID, frc::Color color)
{
  auto animationColor = ColorToRGB(color);
  cx_SetColor(_connectorXInternal, zoneID.data(), animationColor);
}

void lumyn::device::ConnectorXAnimate::SetGroupColor(std::string_view groupID, frc::Color color)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupColor(_connectorXInternal, groupID.data(), animationColor);
}

void lumyn::device::ConnectorXAnimate::SetAnimation(std::string_view zoneID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetAnimation(_connectorXInternal, zoneID.data(), animation, animationColor, delay, reversed, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetGroupAnimation(std::string_view groupID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupAnimation(_connectorXInternal, groupID.data(), animation, animationColor, delay, reversed, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID)
{
  cx_SetAnimationSequence(_connectorXInternal, zoneID.data(), sequenceID.data());
}

void lumyn::device::ConnectorXAnimate::SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID)
{
  cx_SetGroupAnimationSequence(_connectorXInternal, groupID.data(), sequenceID.data());
}

void lumyn::device::ConnectorXAnimate::SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetBitmap(_connectorXInternal, zoneID.data(), sequenceID.data(), animationColor, setColor, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetBitmap(_connectorXInternal, groupID.data(), sequenceID.data(), animationColor, setColor, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetMatrixText(std::string_view zoneID, std::string_view text, frc::Color color,
                                                     lumyn::internal::Command::LED::MatrixTextScrollDirection direction,
                                                     units::millisecond_t delayMs, bool oneShot)
{
  auto textColor = ColorToRGB(color);
  cx_SetText(_connectorXInternal, zoneID.data(), text.data(), textColor, direction, delayMs, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetGroupMatrixText(std::string_view groupID, std::string_view text, frc::Color color,
                                                          lumyn::internal::Command::LED::MatrixTextScrollDirection direction,
                                                          units::millisecond_t delayMs, bool oneShot)
{
  auto textColor = ColorToRGB(color);
  cx_SetGroupText(_connectorXInternal, groupID.data(), text.data(), textColor, direction, delayMs, oneShot);
}
